const express = require('express');
const router = express.Router();
const { register, getUser } = require('../controllers/userController');

router.post('/register', register);
router.get('/:id', getUser);

module.exports = router;