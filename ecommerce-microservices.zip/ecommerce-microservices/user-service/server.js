const express = require('express');
const mongoose = require('mongoose');
const userRoutes = require('./routes/userRoutes');

const app = express();
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/userDB');
app.use('/users', userRoutes);

app.listen(3001, () => console.log('User Service running on port 3001'));