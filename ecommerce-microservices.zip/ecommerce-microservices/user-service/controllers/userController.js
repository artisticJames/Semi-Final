const User = require('../models/User');

exports.register = async (req, res) => {
  const user = new User(req.body);
  await user.save();
  res.json(user);
};

exports.getUser = async (req, res) => {
  const user = await User.findById(req.params.id);
  res.json(user);
};