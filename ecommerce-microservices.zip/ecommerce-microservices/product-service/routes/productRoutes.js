const express = require('express');
const router = express.Router();
const { addProduct, getProduct } = require('../controllers/productController');

router.post('/', addProduct);
router.get('/:id', getProduct);

module.exports = router;