const express = require('express');
const mongoose = require('mongoose');
const productRoutes = require('./routes/productRoutes');

const app = express();
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/productDB');
app.use('/products', productRoutes);

app.listen(3002, () => console.log('Product Service running on port 3002'));