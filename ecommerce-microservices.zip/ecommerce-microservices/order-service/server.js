const express = require('express');
const mongoose = require('mongoose');
const axios = require('axios');
const Order = require('./models/Order');

const app = express();
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/orderDB');

app.post('/orders', async (req, res) => {
  const { userId, productId } = req.body;
  const user = await axios.get(`http://localhost:3001/users/${userId}`);
  const product = await axios.get(`http://localhost:3002/products/${productId}`);

  const order = new Order({ userId, productId });
  await order.save();
  res.json({ order, user: user.data, product: product.data });
});

app.listen(3003, () => console.log('Order Service running on port 3003'));