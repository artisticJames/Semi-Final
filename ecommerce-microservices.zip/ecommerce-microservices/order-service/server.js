const express = require('express');
const mongoose = require('mongoose');
const axios = require('axios');
const Order = require('./models/Order');

const app = express();
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/orderDB');

// Route for placing an order
app.post('/orders', async (req, res) => {
  const { userId, productId } = req.body;

  try {
    // Fetching user data from User Service
    console.log(`Making request to User Service for userId: ${userId}`);
    const user = await axios.get(`http://localhost:3001/users/${userId}`);
    console.log('User fetched:', user.data);

    // Fetching product data from Product Service
    console.log(`Making request to Product Service for productId: ${productId}`);
    const product = await axios.get(`http://localhost:3002/products/${productId}`);
    console.log('Product fetched:', product.data);

    // Creating order and saving to database
    const order = new Order({ userId, productId });
    await order.save();

    // Sending response with order, user, and product data
    res.json({ order, user: user.data, product: product.data });

  } catch (err) {
    // Log the error and send a detailed error message to the client
    console.error('Error placing order:', err.message);
    res.status(500).json({ error: 'Failed to place order', details: err.message });
  }
});

app.listen(3003, () => console.log('Order Service running on port 3003'));
